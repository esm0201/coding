package com.mksys.arapp.activityresult0314;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class Setting extends AppCompatActivity {
    EditText mName, mIP, mPort;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        mName = (EditText) findViewById(R.id.setting_name);
        mIP = (EditText) findViewById(R.id.setting_ip);
        mPort = (EditText) findViewById(R.id.setting_port);
    }

    public void onSave(View v) {
        Intent in = new Intent();
        in.putExtra("NETWORK_NAME", mName.getText().toString());
        in.putExtra("NETWORK_IP", mIP.getText().toString());
        in.putExtra("NETWORK_PORT", mPort.getText().toString());
        setResult(RESULT_OK, in);
        finish();
    }

    public void onCancel(View v) {
        finish();
    }
}
