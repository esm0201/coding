package com.mksys.arapp.activityresult0314;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static int count = 1;
    static final int NETWORK_SETTING_REQUEST = 1000;
    CustomList adapter;
    ListView list;
    ArrayList<SettingData> mListSetting = new ArrayList<>();

    public class SettingData {
        String name;
        String ip;
        String port;

        public SettingData(String name, String ip, String port) {
            this.name = name;
            this.ip = ip;
            this.port = port;
        }

        public String getName() {
            return name;
        }

        public String getIp() {
            return ip;
        }

        public String getPort() {
            return port;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        adapter = new CustomList(this);
        list = (ListView) findViewById(R.id.list);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                SettingData item = (SettingData)parent.getItemAtPosition(position);
                Toast.makeText(getBaseContext(), item.getName(), Toast.LENGTH_SHORT).show();
                connectNetwork(item.getName());
            }
        });

        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                deleteItem(item, position);
                return true;
            }
        });
    }

    public void deleteItem(String data, final int pos) {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("선택한 목록을 삭제하시겠습니까?");
        builder.setPositiveButton("네", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mListSetting.remove(pos);
                adapter.notifyDataSetChanged();
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void connectNetwork(String data) {
        LayoutInflater inflater =
                (LayoutInflater) getApplicationContext().getSystemService(
                        LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.coustom_dlg_layout, null);
        TextView customTitle = (TextView) view.findViewById(R.id.customtitle);
        customTitle.setText("["+data+"]"+" 설정한 네트웍 정보로 접속하시겠습니까?");
        customTitle.setTextColor(Color.BLACK);
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setView(view);
        builder.setPositiveButton("네", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    /*
    ** hack4ork_190813 사용 X
    * +++++++++++++++++++++++++++++++++++++++
    @Override
    protected void onStart() {
        super.onStart();
        int i = adapter.getCount();
        if (i > 0) {
//            adapter.notifyDataSetChanged();
            list.setAdapter(adapter);
        }
    }
    * +++++++++++++++++++++++++++++++++++++++ */

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == NETWORK_SETTING_REQUEST
                && resultCode == RESULT_OK) {
            String name = data.getStringExtra("NETWORK_NAME");
            String ip = data.getStringExtra("NETWORK_IP");
            String port = data.getStringExtra("NETWORK_PORT");
            Toast.makeText(this, name + ":" + ip + ":" + port, Toast.LENGTH_SHORT).show();
            mListSetting.add(new SettingData(name, ip, port));
        }
    }

    public void onSetting(View v) {
        Intent in = new Intent(this, Setting.class);
        startActivityForResult(in, NETWORK_SETTING_REQUEST);
    }

    public class CustomList extends ArrayAdapter<SettingData> {
        private final Activity context;

        public CustomList(Activity context) {
            super(context, R.layout.listitem, mListSetting);
            this.context = context;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {
            return displayItems(position);
        }

        public View displayItems(int pos) {
            LayoutInflater inflater = context.getLayoutInflater();
            View rowView = inflater.inflate(R.layout.listitem, null, true);
            ImageView imageView = (ImageView) rowView.findViewById(R.id.image);
            TextView title = (TextView) rowView.findViewById(R.id.title);
            TextView rating = (TextView) rowView.findViewById(R.id.rating);
            TextView genre = (TextView) rowView.findViewById(R.id.genre);
            TextView year = (TextView) rowView.findViewById(R.id.releaseYear);

            title.setText(mListSetting.get(pos).getName());
            rating.setText(mListSetting.get(pos).getIp());
            genre.setText(mListSetting.get(pos).getPort());
            year.setText((count + pos) + "");
            imageView.setImageResource(R.drawable.ic_tap_and_play_black_40dp);
            return rowView;
        }
    }
}