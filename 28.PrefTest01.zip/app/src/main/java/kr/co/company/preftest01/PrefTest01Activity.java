package kr.co.company.preftest01;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

public class PrefTest01Activity extends Activity {
	public static final String PREFS_NAME = "MyPrefs";
	TextView name;
	EditText value;
	String imageName;

	@Override
	protected void onCreate(Bundle state){
		super.onCreate(state);
		setContentView(R.layout.main);

		name = (TextView)findViewById(R.id.TextView01);
		value = (EditText)findViewById(R.id.EditText01);

		// 안드로이드 메모리공간에 저장된 Preference를 복원.
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
		imageName = settings.getString("imageName", "");
		value.setText(imageName);
	}

	@Override
	protected void onStop(){
        Log.d("hack4ork", "onStop()...");
		super.onStop();
		SharedPreferences settings =
				getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
		// 프레퍼런스에 값을 기록하려면 Editor 객체가 필요
		SharedPreferences.Editor editor = settings.edit();
		imageName = value.getText().toString();
		editor.putString("imageName", imageName);
		// 변경을 최종 반영한다.
		editor.commit();

		/*
		// 키값 삭제
		editor.remove("imageName");
		editor.commit();

		// 모든키값 삭제
		editor.clear();
		editor.commit();
		*/
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.d("hack4ork", "onDestroy()...");
	}
}