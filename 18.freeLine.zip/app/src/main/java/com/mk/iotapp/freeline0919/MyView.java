package com.mk.iotapp.freeline0919;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class MyView extends View {
    Paint mPaint;
    MainActivity mAct;

    public MyView(Context context) {
        super(context);
        mAct = (MainActivity)context;
        mPaint = new Paint();
        mPaint.setColor(Color.BLUE);
        mPaint.setStrokeWidth(10);
        mPaint.setAntiAlias(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int e = event.getAction();

        switch (e) {
            case MotionEvent.ACTION_DOWN:
                mAct.getVertextList().add(new Vertex(event.getX(), event.getY(), false));
                break;

            case MotionEvent.ACTION_MOVE:
                mAct.getVertextList().add(new Vertex(event.getX(), event.getY(), true));
                invalidate();
                break;
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.LTGRAY);

        for (int i=0;i<mAct.getVertextList().size();i++) {
            if (mAct.getVertextList().get(i).draw) {
                canvas.drawLine(mAct.getVertextList().get(i-1).x,
                        mAct.getVertextList().get(i-1).y,
                        mAct.getVertextList().get(i).x,
                        mAct.getVertextList().get(i).y, mPaint);
            }
        }
    }
}