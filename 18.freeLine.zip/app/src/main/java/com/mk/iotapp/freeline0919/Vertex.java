package com.mk.iotapp.freeline0919;

public class Vertex {
    float x;
    float y;
    boolean draw;

    Vertex(float ax, float ay, boolean ad) {
        x = ax;
        y = ay;
        draw = ad;
    }
}