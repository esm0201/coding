package com.mk.iotapp.freeline0919;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private MyView vw;
    private ArrayList<Vertex> arVertex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        arVertex = new ArrayList<Vertex>();
        vw = new MyView(this);
        setContentView(vw);
    }

    public ArrayList<Vertex> getVertextList() {
        return arVertex;
    }
}
